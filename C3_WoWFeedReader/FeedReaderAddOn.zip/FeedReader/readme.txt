1. Place me inside the World of Warcraft>>Interface>>AddOns directory
2. Ensure that FeedGrabber is on and that you have RSS feeds added
3. If you don't want to use FeedGrabber, you can see a sample of what the AddOn looks like by
	- Renaming "SAMPLE_FeedReader.lua" to "FeedReader.lua"
	- Copying "FeedReader.lua" to the World of Warcraft>>WTF>>Account>>[AccountName]>>SaveVariables file

